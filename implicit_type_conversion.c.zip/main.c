#include<stdio.h>
#include<conio.h>
 main()
  {
    int a=8 ;
    float b=5,c;
    c=a/b;
    printf("%f",c);
  }