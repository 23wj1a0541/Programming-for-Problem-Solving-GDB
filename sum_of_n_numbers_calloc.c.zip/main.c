#include<stdio.h>
#include<conio.h>
#include<malloc.h>
 main()
  {
      int *ptr,n,i,sum=0;
      printf("Enter the n value ");
      scanf("%d",&n);
      ptr=(int *)calloc(n , sizeof(int));
      for(i=0;i<n;i++)
       scanf("%d",ptr+i);
      for(i=0;i<n;i++)
       sum=sum + *(ptr+i);
      printf("%d",sum); 
  }








