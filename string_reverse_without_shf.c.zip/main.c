#include<stdio.h>
#include<conio.h>
 main()
  {
      int i=0,j,k=0;
      char name1[20],name2[20];
      printf("Enter the first string ");
      gets(name1);
      while(name1[i]!='\0')
       i++;
      for(j=i-1;j>=0;j--)
       {
           name2[k]=name1[j];
           k++;
       }
      name2[k]='\0';
      printf("The reverse string is ");
      puts(name2);
  }
