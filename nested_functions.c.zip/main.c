#include<stdio.h>
#include<conio.h>
 main()
  {
      message1();
      message2();
      message3();
      message4();
  }
 message2()
  {
      printf("GA ");
  }
 message4()
  {
      printf("GN ");
  }
 message3()
  {
      printf("GE ");
  }
 message1()
  {
      printf("GM ");
  }  
  