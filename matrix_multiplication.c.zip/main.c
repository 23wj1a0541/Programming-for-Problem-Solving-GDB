#include<stdio.h>
#include<conio.h>
 main()
  {
      int a[5][5],b[5][5],c[5][5],m1,n1,m2,n2,i,j,k;
      printf("Enter the number of rows and coloumns of the first matrix A ");
      scanf("%d %d",&m1,&n1);
      printf("Enter the first matrix \n");
      for(i=0;i<m1;i++)
       {
           for(k=0;k<n1;k++)
            scanf("%d",&a[i][k]);
       }
      printf("Enter the number of rows and coloumns of the second matrix B ");
      scanf("%d %d",&m2,&n2);
      printf("Enter the second matrix \n");
      for(k=0;k<m2;k++)
       {
           for(j=0;j<n2;j++)
            scanf("%d",&b[k][j]);
       }
      if(n1==m2)
       {
           for(i=0;i<m1;i++)
            {
                for(j=0;j<n2;j++)
                 {
                  c[i][j]=0;     
                  for(k=0;k<n1;k++) 
                   c[i][j]= c[i][j] + (a[i][k]*b[k][j]);
                 }
            }
           printf("The multiplication of 2 matrices of orders %dx%d and %dx%d is \n",m1,n1,m2,n2);
           for(i=0;i<m1;i++)
            {
                for(j=0;j<n2;j++)
                 printf(" %d",c[i][j]);
                printf("\n"); 
            }
           printf("The product of the 2 matrices of order %dx%d and %dx%d has an order of %dx%d",m1,n1,m2,n2,m1,n2);
       }
      else
       printf("The matrix A and B cannot be multiplied as n1 is not equal to m2");
  }     
     






