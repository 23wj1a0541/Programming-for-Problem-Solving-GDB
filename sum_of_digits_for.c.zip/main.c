#include<stdio.h>
#include<conio.h>
 main()
  {
      int n,rem,sum;
      printf("Enter the number ");
      scanf("%d",&n);
      for(sum=0;n>0;n=n/10)
       {
           rem=n%10;
           sum=sum+rem;
       }
      printf("The sum of the digits in n is %d",sum); 
  }

