#include<stdio.h>
#include<conio.h>
main()
{
    int a=8,b=5,c;
    c=a+b;
    printf("The sum of %d and %d is %d\n",a,b,c);
    c=a-b;
    printf("The difference of %d and %d is %d\n",a,b,c);
    c=a*b;
    printf("The product of %d and %d is %d\n",a,b,c);
    c=a/b;
    printf("The quotient of %d and %d is %d\n",a,b,c);
    c=a%b;
    printf("The remainder of %d and %d is %d\n",a,b,c);
}