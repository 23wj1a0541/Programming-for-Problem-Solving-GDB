#include<stdio.h>
#include<conio.h>
#include<string.h>
 main()
  {
    char name1[20],name2[20];
    printf("Enter the first string ");
    gets(name1);
    printf("Enter the second string ");
    gets(name2);
    strcat(name1,name2);
    printf("The combined string is ");
    puts(name1);
    printf("The second string is ");
    puts(name2);
  }