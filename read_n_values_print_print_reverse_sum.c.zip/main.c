#include<stdio.h>
#include<conio.h>
 main()
  {
      int a[20],n,i,sum=0;
      printf("Enter the n value ");
      scanf("%d",&n);
      printf("Enter the values ");
      for(i=0;i<n;i++)
       scanf("%d",&a[i]);
      printf("\n The entered n values are ");
      for(i=0;i<n;i++)
       printf("%d",a[i]);
      printf("\nThe n values in reverse order are ");
      for(i=n-1;i>=0;i--)
       printf("%d",a[i]);
      printf("\nThe sum of n values are "); 
      for(i=0;i<n;i++)
       sum=sum+a[i];
      printf("%d",sum); 
  }
