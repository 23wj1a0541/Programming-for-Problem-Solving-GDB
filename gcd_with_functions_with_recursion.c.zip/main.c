#include<stdio.h>
#include<conio.h>
 main()
  {
      int a,b,g1;
      int rgcd(int,int);
      printf("Enter the 2 values ");
      scanf("%d %d",&a,&b);
      g1=rgcd(a,b);
      printf("The GCD of 2 numbers is %d",g1);
  }
 int rgcd(int a,int b) 
  {
      if(a==0)
       return(b);
      else
       return(rgcd((b%a),a));
  }