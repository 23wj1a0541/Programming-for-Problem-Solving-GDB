#include<stdio.h>
#include<conio.h>
 main()
  {
      int per;
      printf("Enter the percentage");
      scanf("%d",&per);
      if(per>70)
       printf("Distincion");
      if(per<70 && per>=60) 
       printf("First Class");
      if(per<60 && per>=50)
       printf("Second Class");
      if(per<50 && per>=40)
       printf("Third Class");
      if(per<40)
       printf("Fail");
  }