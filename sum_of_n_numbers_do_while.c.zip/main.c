#include<stdio.h>
#include<conio.h>
 main()
  {
      int n,i=1,sum=0;
      printf("Enter n value ");
      scanf("%d",&n);
      do
       {
           sum=sum+i;
           i++;
       }while(i<=n);
      printf("%d",sum); 
  }

