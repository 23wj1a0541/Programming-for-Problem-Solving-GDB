#include<stdio.h>
#include<conio.h>
 main()
  {
      int per,ch;
      printf("Enter the percentage ");
      scanf("%d",&per);
      ch=per/10;
      switch(ch)
       {
           case 10 :
           case 9  :
           case 8  :
           case 7  : printf("Distinction");
                     break; 
           case 6  : printf("First Class");
                     break;
           case 5  : printf("Second Class");
                     break;
           case 4  : printf("Third Class");
                     break;
           case 3  :
           case 2  :
           case 1  :
           case 0  : printf("Fail");
                     break;
       }
  }