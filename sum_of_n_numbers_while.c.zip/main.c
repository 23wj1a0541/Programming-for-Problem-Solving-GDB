#include<stdio.h>
#include<conio.h>
 main()
  {
      int n,i=1,sum=0;
      printf("Enter n value ");
      scanf("%d",&n);
      while(i<=n)
       {
           sum=sum+i;
           i++;
       }
      printf("%d",sum); 
  }