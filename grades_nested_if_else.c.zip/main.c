#include<stdio.h>
#include<conio.h>
 main()
  {
      int per;
      printf("Enter the percentage");
      scanf("%d",&per);
      if(per>=70)
       printf("Distinction");
      else
       {
           if(per<70 && per>=60)
            printf("First Class");
           else
            {
                if(per<60 && per>=50)
                 printf("Second Class");
                else
                 {
                 if(per<50 && per>40)
                  printf("Second Class");
                 else
                  printf("Fail");
                 } 
            }
       }
  }