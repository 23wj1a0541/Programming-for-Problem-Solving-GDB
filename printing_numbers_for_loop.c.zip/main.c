#include<stdio.h>
#include<conio.h>
 main()
  {
      int i,n;
      printf("printing natural numbers from 1 to n \n");
      printf("Enter the value of n ");
      scanf("%d",&n);
      for(i=1;i<=n;i++)
        printf("%d ",i);
      printf("\nprinting natural numbers from n to 1 \n");
      printf("Enter the value of n ");
      scanf("%d",&n);
      for(i=n;i>=1;i--)
        printf("%d ",i);
      printf("\n printing even numbers from 0 to n");
      printf("Enter the value of n ");
      scanf("%d",&n);
      for(i=0;i<=n;i+=2)
        printf("%d ",i);
  }

