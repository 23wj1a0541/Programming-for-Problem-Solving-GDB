#include<stdio.h>
#include<conio.h>
 main()
  {
      int a[20],n,i;
      void selectionsort(int [],int);
      printf("Enter the n value ");
      scanf("%d",&n);
      printf("Enter n values in the array ");
      for(i=0;i<n;i++)
       scanf("%d",&a[i]);
      selectionsort(a,n);
      printf("The ascending sorted array with selectionsort is ");
      for(i=0;i<n;i++)
       printf("%d ",a[i]);
  }
 void selectionsort(int a[],int n)
  {
      int pass,t,j,min;
      for(pass=0;pass<n-1;pass++)
       {
           min=pass;
           for(j=pass+1;j<n;j++)
            {
                if(a[j]<a[min])
                 min=j;
            }
           t=a[pass];
           a[pass]=a[min];
           a[min]=t;
       }
  }
