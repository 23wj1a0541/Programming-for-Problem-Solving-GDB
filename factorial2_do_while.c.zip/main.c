#include<stdio.h>
#include<conio.h>
 main()
  {
      int n,i,fact=1;
      printf("Enter n value ");
      scanf("%d",&n);
      printf("%d=",n);
      i=n;
      do
       {
           fact=fact*i;
           if(i!=1)
            printf("%d*",i);
           else
            printf("%d",i);
           i--;
       }while(i>=1);
      printf("\nThe factorial of %d is %d",n,fact); 
  } 


