#include<stdio.h>
#include<conio.h>
 main()
  {
      int a[20],n,*p,i;
      p=&a[0];
      printf("Enter the n value ");
      scanf("%d",&n);
      printf("Enter the array values ");
      for(i=0;i<n;i++)
       scanf("%d",&a[i]);
      printf("The entered array values using pointers are ");
      for(i=0;i<n;i++)
       printf("%d ",*(p+i));
      printf("\nThe reverse of array values using pointers are "); 
      for(i=n-1;i>=0;i--)
       printf("%d ",*(p+i));
  }