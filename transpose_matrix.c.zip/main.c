#include<stdio.h>
#include<conio.h>
 main()
  {
      int a[5][5],i,j,m,n;
      printf("Enter the number of rows and coloumns of matrix A \n");
      scanf("%d %d",&m,&n);
      printf("The order of the matrix A is mxn\n");
      printf("Enter the elements of the matrix of order %dx%d \n",m,n);
      for(i=0;i<m;i++)
       {
           for(j=0;j<n;j++)
            scanf("%d",&a[i][j]);
       }
      printf("The matrix A of order %dx%d is \n");
      for(i=0;i<m;i++)
       {
           for(j=0;j<n;j++)
            printf("%d ",a[i][j]);
           printf("\n");    
       }
      printf("The order of the matrix transpose of A is nxm\n");
      printf("The transpose matrix of A of order %dx%d is \n",n,m);
      for(j=0;j<n;j++)
       {
           for(i=0;i<m;i++)
            printf("%d ",a[i][j]);
           printf("\n");    
       }
  }
