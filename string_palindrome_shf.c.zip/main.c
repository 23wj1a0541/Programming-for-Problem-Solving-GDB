#include<stdio.h>
#include<conio.h>
#include<string.h>
 main()
  {
      char name1[20],name2[20];
      int n;
      printf("Enter the first string ");
      gets(name1);
      strcpy(name2,name1);
      strrev(name1);
      n=strcmp(name1,name2);
      if(n==0)
       printf("It is a palindrome");
      else
       printf("It is not a palindrome");
  }