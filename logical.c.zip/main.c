#include<stdio.h>
#include<conio.h>
main()
{
    int a=5,b=7,c;
    
    printf("\n\nThe combination of all the 6 relational operators with the logical operator && \n\n");
    c=(a<b)&&(a<b);
    printf("comparing (%d<%d)&&(%d<%d) is %d\n",a,b,a,b,c);
    c=(a<b)&&(a<=b);
    printf("comparing (%d<%d)&&(%d<=%d) is %d\n",a,b,a,b,c);
    c=(a<b)&&(a>b);
    printf("comparing (%d<%d)&&(%d>%d) is %d\n",a,b,a,b,c);
    c=(a<b)&&(a>=b);
    printf("comparing (%d<%d)&&(%d>=%d) is %d\n",a,b,a,b,c);
    c=(a<b)&&(a==b);
    printf("comparing (%d<%d)&&(%d==%d) is %d\n",a,b,a,b,c);
    c=(a<b)&&(a!=b);
    printf("comparing (%d<%d)&&(%d!=%d) is %d\n",a,b,a,b,c);
    c=(a<=b)&&(a<b);
    printf("comparing (%d<=%d)&&(%d<%d) is %d\n",a,b,a,b,c);
    c=(a<=b)&&(a<=b);
    printf("comparing (%d<=%d)&&(%d<=%d) is %d\n",a,b,a,b,c);
    c=(a<=b)&&(a>b);
    printf("comparing (%d<=%d)&&(%d>%d) is %d\n",a,b,a,b,c);
    c=(a<=b)&&(a>=b);
    printf("comparing (%d<=%d)&&(%d>=%d) is %d\n",a,b,a,b,c);
    c=(a<=b)&&(a==b);
    printf("comparing (%d<=%d)&&(%d==%d) is %d\n",a,b,a,b,c);
    c=(a<=b)&&(a!=b);
    printf("comparing (%d<=%d)&&(%d!=%d) is %d\n",a,b,a,b,c);
    c=(a>b)&&(a<b);
    printf("comparing (%d>%d)&&(%d<%d) is %d\n",a,b,a,b,c);
    c=(a>b)&&(a<=b);
    printf("comparing (%d>%d)&&(%d<=%d) is %d\n",a,b,a,b,c);
    c=(a>b)&&(a>b);
    printf("comparing (%d>%d)&&(%d>%d) is %d\n",a,b,a,b,c);
    c=(a>b)&&(a>=b);
    printf("comparing (%d>%d)&&(%d>=%d) is %d\n",a,b,a,b,c);
    c=(a>b)&&(a==b);
    printf("comparing (%d>%d)&&(%d==%d) is %d\n",a,b,a,b,c);
    c=(a>b)&&(a!=b);
    printf("comparing (%d>%d)&&(%d!=%d) is %d\n",a,b,a,b,c);
    c=(a>=b)&&(a<b);
    printf("comparing (%d>=%d)&&(%d<%d) is %d\n",a,b,a,b,c);
    c=(a>=b)&&(a<=b);
    printf("comparing (%d>=%d)&&(%d<=%d) is %d\n",a,b,a,b,c);
    c=(a>=b)&&(a>b);
    printf("comparing (%d>=%d)&&(%d>%d) is %d\n",a,b,a,b,c);
    c=(a>=b)&&(a>=b);
    printf("comparing (%d>=%d)&&(%d>=%d) is %d\n",a,b,a,b,c);
    c=(a>=b)&&(a==b);
    printf("comparing (%d>=%d)&&(%d==%d) is %d\n",a,b,a,b,c);
    c=(a>=b)&&(a!=b);
    printf("comparing (%d>=%d)&&(%d!=%d) is %d\n",a,b,a,b,c);
    c=(a==b)&&(a<b);
    printf("comparing (%d==%d)&&(%d<%d) is %d\n",a,b,a,b,c);
    c=(a==b)&&(a<=b);
    printf("comparing (%d==%d)&&(%d<=%d) is %d\n",a,b,a,b,c);
    c=(a==b)&&(a>b);
    printf("comparing (%d==%d)&&(%d>%d) is %d\n",a,b,a,b,c);
    c=(a==b)&&(a>=b);
    printf("comparing (%d==%d)&&(%d>=%d) is %d\n",a,b,a,b,c);
    c=(a==b)&&(a==b);
    printf("comparing (%d==%d)&&(%d==%d) is %d\n",a,b,a,b,c);
    c=(a==b)&&(a!=b);
    printf("comparing (%d==%d)&&(%d!=%d) is %d\n",a,b,a,b,c);
    c=(a!=b)&&(a<b);
    printf("comparing (%d!=%d)&&(%d<%d) is %d\n",a,b,a,b,c);
    c=(a!=b)&&(a<=b);
    printf("comparing (%d!=%d)&&(%d<=%d) is %d\n",a,b,a,b,c);
    c=(a!=b)&&(a>b);
    printf("comparing (%d!=%d)&&(%d>%d) is %d\n",a,b,a,b,c);
    c=(a!=b)&&(a>=b);
    printf("comparing (%d!=%d)&&(%d>=%d) is %d\n",a,b,a,b,c);
    c=(a!=b)&&(a==b);
    printf("comparing (%d!=%d)&&(%d==%d) is %d\n",a,b,a,b,c);
    c=(a!=b)&&(a!=b);
    printf("comparing (%d!=%d)&&(%d!=%d) is %d\n",a,b,a,b,c);
    
    printf("\n\nThe combination of all the 6 relational operators with the logical operator || \n\n");
    c=(a<b)||(a<b);
    printf("comparing (%d<%d)||(%d<%d) is %d\n",a,b,a,b,c);
    c=(a<b)||(a<=b);
    printf("comparing (%d<%d)||(%d<=%d) is %d\n",a,b,a,b,c);
    c=(a<b)||(a>b);
    printf("comparing (%d<%d)||(%d>%d) is %d\n",a,b,a,b,c);
    c=(a<b)||(a>=b);
    printf("comparing (%d<%d)||(%d>=%d) is %d\n",a,b,a,b,c);
    c=(a<b)||(a==b);
    printf("comparing (%d<%d)||(%d==%d) is %d\n",a,b,a,b,c);
    c=(a<b)||(a!=b);
    printf("comparing (%d<%d)||(%d!=%d) is %d\n",a,b,a,b,c);
    c=(a<=b)||(a<b);
    printf("comparing (%d<=%d)||(%d<%d) is %d\n",a,b,a,b,c);
    c=(a<=b)||(a<=b);
    printf("comparing (%d<=%d)||(%d<=%d) is %d\n",a,b,a,b,c);
    c=(a<=b)||(a>b);
    printf("comparing (%d<=%d)||(%d>%d) is %d\n",a,b,a,b,c);
    c=(a<=b)||(a>=b);
    printf("comparing (%d<=%d)||(%d>=%d) is %d\n",a,b,a,b,c);
    c=(a<=b)||(a==b);
    printf("comparing (%d<=%d)||(%d==%d) is %d\n",a,b,a,b,c);
    c=(a<=b)||(a!=b);
    printf("comparing (%d<=%d)||(%d!=%d) is %d\n",a,b,a,b,c);
    c=(a>b)||(a<b);
    printf("comparing (%d>%d)||(%d<%d) is %d\n",a,b,a,b,c);
    c=(a>b)||(a<=b);
    printf("comparing (%d>%d)||(%d<=%d) is %d\n",a,b,a,b,c);
    c=(a>b)||(a>b);
    printf("comparing (%d>%d)||(%d>%d) is %d\n",a,b,a,b,c);
    c=(a>b)||(a>=b);
    printf("comparing (%d>%d)||(%d>=%d) is %d\n",a,b,a,b,c);
    c=(a>b)||(a==b);
    printf("comparing (%d>%d)||(%d==%d) is %d\n",a,b,a,b,c);
    c=(a>b)||(a!=b);
    printf("comparing (%d>%d)||(%d!=%d) is %d\n",a,b,a,b,c);
    c=(a>=b)||(a<b);
    printf("comparing (%d>=%d)||(%d<%d) is %d\n",a,b,a,b,c);
    c=(a>=b)||(a<=b);
    printf("comparing (%d>=%d)||(%d<=%d) is %d\n",a,b,a,b,c);
    c=(a>=b)||(a>b);
    printf("comparing (%d>=%d)||(%d>%d) is %d\n",a,b,a,b,c);
    c=(a>=b)||(a>=b);
    printf("comparing (%d>=%d)||(%d>=%d) is %d\n",a,b,a,b,c);
    c=(a>=b)||(a==b);
    printf("comparing (%d>=%d)||(%d==%d) is %d\n",a,b,a,b,c);
    c=(a>=b)||(a!=b);
    printf("comparing (%d>=%d)||(%d!=%d) is %d\n",a,b,a,b,c);
    c=(a==b)||(a<b);
    printf("comparing (%d==%d)||(%d<%d) is %d\n",a,b,a,b,c);
    c=(a==b)||(a<=b);
    printf("comparing (%d==%d)||(%d<=%d) is %d\n",a,b,a,b,c);
    c=(a==b)||(a>b);
    printf("comparing (%d==%d)||(%d>%d) is %d\n",a,b,a,b,c);
    c=(a==b)||(a>=b);
    printf("comparing (%d==%d)||(%d>=%d) is %d\n",a,b,a,b,c);
    c=(a==b)||(a==b);
    printf("comparing (%d==%d)||(%d==%d) is %d\n",a,b,a,b,c);
    c=(a==b)||(a!=b);
    printf("comparing (%d==%d)||(%d!=%d) is %d\n",a,b,a,b,c);
    c=(a!=b)||(a<b);
    printf("comparing (%d!=%d)||(%d<%d) is %d\n",a,b,a,b,c);
    c=(a!=b)||(a<=b);
    printf("comparing (%d!=%d)||(%d<=%d) is %d\n",a,b,a,b,c);
    c=(a!=b)||(a>b);
    printf("comparing (%d!=%d)||(%d>%d) is %d\n",a,b,a,b,c);
    c=(a!=b)||(a>=b);
    printf("comparing (%d!=%d)||(%d>=%d) is %d\n",a,b,a,b,c);
    c=(a!=b)||(a==b);
    printf("comparing (%d!=%d)||(%d==%d) is %d\n",a,b,a,b,c);
    c=(a!=b)||(a!=b);
    printf("comparing (%d!=%d)||(%d!=%d) is %d\n",a,b,a,b,c);
    
    printf("\n\nThe combination of all the 6 relational operators with the logical operator ! \n\n");
    c=!(a<b);
    printf("The value of c=!(%d<%d) is %d\n",a,b,c);
    c=!(a<=b);
    printf("The value of c=!(%d<=%d) is %d\n",a,b,c);
    c=!(a>b);
    printf("The value of c=!(%d>%d) is %d\n",a,b,c);
    c=!(a>=b);
    printf("The value of c=!(%d>=%d) is %d\n",a,b,c);
    c=!(a==b);
    printf("The value of c=!(%d==%d) is %d\n",a,b,c);
    c=!(a!=b);
    printf("The value of c=!(%d!=%d) is %d\n",a,b,c);
}























