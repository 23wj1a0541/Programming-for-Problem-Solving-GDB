#include<stdio.h>
#include<conio.h>
 main()
  {
      int a,b,g1;
      int gcd(int,int);
      printf("Enter the 2 values ");
      scanf("%d %d",&a,&b);
      g1=gcd(a,b);
      printf("The GCD of 2 numbers is %d",g1);
  }
 int gcd(int a,int b) 
  {
      int r;
      while(a!=0)
       {
           r=b%a;
           b=a;
           a=r;
       }
      return(b); 
  }