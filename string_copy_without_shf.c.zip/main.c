#include<stdio.h>
#include<conio.h>
 main()
  {
      char name[20],name1[20];
      int i=0;
      printf("Enter the string name = ");
      gets(name);
      while(name[i]!='\0')
       {
           name1[i]=name[i];
           i++;
       }
      name1[i]='\0';
      printf("The copied string name1 = ");
      puts(name1);
  }
