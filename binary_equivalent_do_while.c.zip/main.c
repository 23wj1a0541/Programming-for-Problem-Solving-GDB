#include<stdio.h>
#include<conio.h>
 main()
  {
      int num,rem,bin=0,i=1;
      printf("Enter the number ");
      scanf("%d",&num);
      do
       {
           rem=num%2;
           bin=bin+(rem*i);
           num=num/2;
           i=i*10;
       }while(num!=0);
      printf("The binary equivalent value is %d",bin); 
  }

