#include<stdio.h>
#include<conio.h>
 main()
  {
      int a=0,b=1,c,n,i=2;
      printf("Enter n value ");
      scanf("%d",&n);
      printf("%d %d ",a,b);
      do
       {
           c=a+b;
           printf("%d ",c);
           a=b;
           b=c;
           i++;
       }while(i<n);
  }

