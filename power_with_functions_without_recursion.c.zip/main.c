#include<stdio.h>
#include<conio.h>
 main()
  {
      int power(int,int);
      int b,p,pw;
      printf("Enter 2 values ");
      scanf("%d %d",&b,&p);
      pw=power(b,p);
      printf("The power is %d",pw);
  }
 int power(int b,int p) 
  {
      int i,p1=1;
      for(i=1;i<=p;i++)
       p1=b*p1;
      return(p1); 
  }