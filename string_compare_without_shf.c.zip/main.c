#include<stdio.h>
#include<conio.h>
 main()
  {
      int n,i,j;
      char name1[20],name2[20];
      printf("Enter the first string ");
      gets(name1);
      printf("Enter the second string ");
      gets(name2);
      for(i=0,j=0;name1[i]!='\0'&&name2[j]!='\0';i++,j++)
       {
        if(name1[i]!=name2[j])
         printf("The 2 strings are not equal");
       }
      if(name1[i]!='\0'&&name2[j]!='\0') 
       printf("The 2 strings are equal");
      else 
       printf("The 2 strings are not equal");    
  }

