#include<stdio.h>
#include<conio.h>
 main()
  {
      char name[20];
      int i=0;
      printf("Enter the string ");
      gets(name);
      while(name[i]!='\0')
       i++;
      printf("The length of the string is %d",i); 
  }
