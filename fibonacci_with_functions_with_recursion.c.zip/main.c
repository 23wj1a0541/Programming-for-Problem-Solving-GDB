#include<stdio.h>
#include<conio.h>
 main()
  {
      int i,n1;
      int fib(int);
      printf("Enter the n1 value ");
      scanf("%d",&n1);
      for(i=0;i<n1;i++)
       printf("%d ",fib(i));
  }
 int fib(int n)
  {
      if(n==0)
       return(0);
      else
       {
           if(n==1)
            return(1);
           else
            return(fib(n-2)+fib(n-1));
       }
  }