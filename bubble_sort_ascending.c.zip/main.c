#include<stdio.h>
#include<conio.h>
 main()
  {
      void bubblesort(int [],int);
      int a[20],n,i;
      printf("Enter the n value ");
      scanf("%d",&n);
      printf("Enter the n numer of values ");
      for(i=0;i<n;i++)
       scanf("%d",&a[i]);
      bubblesort(a,n);
      printf("The sorted array is ");
      for(i=0;i<n;i++)
       printf("%d ",a[i]);
  }
 void bubblesort(int a[],int n)
  {
      int pass,j,flag,t;
      for(pass=0;pass<(n-1);pass++)
       {
           flag=0;
           for(j=0;j<(n-pass-1);j++)
            {
                if(a[j]>a[j+1])
                 {
                     t=a[j];
                     a[j]=a[j+1];
                     a[j+1]=t;
                     flag=1;
                 }
            }
           if(flag==0)
            break;
       }
  }



















