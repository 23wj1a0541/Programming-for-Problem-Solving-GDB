#include<stdio.h>
#include<conio.h>
 struct student
  {
      char name[20];
      int rollno;
      float height;
      int m[3];
  }std1;
 main()
  {
      int i;
      printf("Enter the details of student ");
      scanf("%s %d %f",std1.name,&std1.rollno,&std1.height);
      for(i=0;i<3;i++)
       scanf("%d",&std1.m[i]);
      printf("The details of student1 are ");
      printf("%s %d %f ",std1.name,std1.rollno,std1.height);
      for(i=0;i<3;i++)
       printf("%d ",std1.m[i]);
  }

