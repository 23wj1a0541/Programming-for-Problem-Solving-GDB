#include<stdio.h>
#include<conio.h>
 main()
  {
      int a[99],i,n,max,min,sum=0;
      float avg;
      printf("Enter the size of array ");
      scanf("%d",&n);
      printf("Enter %d elements in a array ",n);
      for(i=0;i<n;i++)
       scanf("%d",&a[i]);
      max=min=a[0];
      for(i=0;i<n;i++)
       {
           if(a[i]>max)
            max=a[i];
           if(a[i]<min)
            min=a[i];
           sum=sum+a[i];    
       }
      avg=(float)sum/n; 
      printf("minimum of %d numbers in the array is %d \n",n,min);
      printf("maximum of %d numbers in the array is %d \n",n,max);
      printf("The average of %d elements in the array is %f",n,avg);
  }

