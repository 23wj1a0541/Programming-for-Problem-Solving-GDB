#include<stdio.h>
#include<conio.h>
 main()
  {
      int n,i,fact;
      printf("Enter n value ");
      scanf("%d",&n);
      printf("%d!=",n);
      for(i=1,fact=1;i<=n;i++)
       {
           fact=fact*i;
           if(i!=n)
            printf("%d*",i);
           else
            printf("%d",i);
       }
      printf("\nThe factorial of %d is %d",n,fact); 
  } 


