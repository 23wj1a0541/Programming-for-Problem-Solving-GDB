#include<stdio.h>
#include<conio.h>
 struct student
  {
      char name[20];
      int Rno;
      int m1;
      int m2;
      int m3;
  }std1;
 main()
  {
      void sum(struct student *);
      printf("Enter the details of student 1 ");
      scanf("%s %d %d %d %d",std1.name,&std1.Rno,&std1.m1,&std1.m2,&std1.m3);
      sum(&std1);
  }
 void sum(struct student *std1)
  {
      int s;
      s=std1->m1+std1->m2+std1->m3;
      printf("sum=%d",s);
  }
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
