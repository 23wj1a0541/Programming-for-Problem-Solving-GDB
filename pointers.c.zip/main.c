#include<stdio.h>
#include<conio.h>
 main()
  {
      int a=10,*p,**p1;
      p=&a;
      p1=&p;
      printf("%d\n",a);
      printf("%d\n",*p);
      printf("%u\n",p);
      printf("%u\n",*p1);
      printf("%d\n",**p1);
      printf("%u\n",&p1);
      printf("%u\n",p1);
      printf("%u\n",&p);
      *p=25;
      printf("%d\n",a);
  }