#include<stdio.h>
#include<conio.h>
#include<math.h>
 main()
  {
      int a,b,c,disc;
      float r1,r2;
      printf("Enter 3 values");
      scanf("%d %d %d",&a,&b,&c);
      disc=(b*b)-(4*a*c);
      if(disc>0)
       {
        r1=(-b+sqrt(disc))/(2*a);
        r2=(-b-sqrt(disc))/(2*a);
        printf("The roots are real and distinct %f and %d",r1,r2);
       }
      else
       {
           if(disc=0)
            {
             r1=r2=(-b)/(2*a);
             printf("The root are real and equal %f",r1);
            }
           else
            printf("The roots are imaginary");
       }
  }