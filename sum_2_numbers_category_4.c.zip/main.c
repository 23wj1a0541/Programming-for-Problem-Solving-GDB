#include<stdio.h>
#include<conio.h>
 main()
  {
      int sum();
      int X;
      X=sum();
      printf("sum=%d",X);
  }
  sum()
   {
       int a,b,c;
       printf("Enter a & b values ");
       scanf("%d %d",&a,&b);
       c=a+b;
       return(c);
   }