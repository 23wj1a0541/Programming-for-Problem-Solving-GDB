#include<stdio.h>
#include<conio.h>
 main()
  {
      int a,b;
      void sum(int,int);
      printf("Enter a & b values ");
      scanf("%d %d",&a,&b);
      sum(a,b);//Actual Argument
  }
  void sum(int c,int d)//Formal Argument
   {
       int z;
       z=c+d;
       printf("sum=%d",z);
   }