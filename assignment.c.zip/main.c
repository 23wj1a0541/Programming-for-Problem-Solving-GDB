#include<stdio.h>
#include<conio.h>
main()
{
    int a=5,b=10,t;
    t=a;
    a=b;
    b=t;
    printf("value of a is %d\n",a);
    printf("value of b is %d\n",b);
}