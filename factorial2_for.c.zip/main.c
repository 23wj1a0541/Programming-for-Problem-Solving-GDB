#include<stdio.h>
#include<conio.h>
 main()
  {
      int n,i,fact;
      printf("Enter n value ");
      scanf("%d",&n);
      printf("%d=",n);
      i=n;
      for(fact=1;i>=1;i--)
       {
           fact=fact*i;
           if(i!=1)
            printf("%d*",i);
           else
            printf("%d",i);
       }
      printf("\nThe factorial of %d is %d",n,fact); 
  } 


