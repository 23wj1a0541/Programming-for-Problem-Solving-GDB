#include<stdio.h>
#include<conio.h>
 main()
  {
      int a,b;
      void swap(int,int);
      printf("Enter the 2 values ");
      scanf("%d %d",&a,&b);
      printf("Before swapping a=%d and b=%d\n",a,b);
      swap(a,b);
      printf("After swapping a=%d and b=%d\n",a,b);
  }
 void swap(int a,int b)
  {
      int t;
      t=a;
      a=b;
      b=t;
      printf("a=%d and b=%d\n",a,b);
  }