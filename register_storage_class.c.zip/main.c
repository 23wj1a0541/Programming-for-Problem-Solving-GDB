#include<stdio.h>
#include<conio.h>
 main()
  {
      sum();
      sum();
      sum();
  }
 void sum()
  {
      register int i=0;
      i=i+1;
      printf("%d ",i);
  }