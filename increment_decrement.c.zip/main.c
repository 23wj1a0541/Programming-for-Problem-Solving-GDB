#include<stdio.h>
#include<conio.h>
main()
{
    int a=3,b;
    b=a++;
    printf("after applying a++,a=%d b=%d\n",a,b);
    b=++a;
    printf("after applying ++a,a=%d b=%d\n",a,b);
    
    b=a--;
    printf("\n\nafter applying a--,a=%d b=%d\n",a,b);
    b=--a;
    printf("after applying --a,a=%d b=%d",a,b);
}