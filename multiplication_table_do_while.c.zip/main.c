#include<stdio.h>
#include<conio.h>
 main()
  {
      int n,m,i=1;
      printf("Enter the n value and m rows ");
      scanf("%d %d",&n,&m);
      do
       {
           printf("%d*%d =%d\n",n,i,n*i);
           i++;
       }while(i<=m);
  }




