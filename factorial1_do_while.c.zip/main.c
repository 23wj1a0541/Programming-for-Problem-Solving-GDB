#include<stdio.h>
#include<conio.h>
 main()
  {
      int n,i=1,fact=1;
      printf("Enter n value ");
      scanf("%d",&n);
      printf("%d!=",n);
      do
       {
           fact=fact*i;
           if(i!=n)
            printf("%d*",i);
           else
            printf("%d",i);
           i++;
       }while(i<=n);
      printf("\nThe factorial of %d is %d",n,fact); 
  } 


