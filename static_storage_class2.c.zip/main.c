#include<stdio.h>
#include<conio.h>
 main()
  {
      sum();
      multi();
      sub();
  }
 void sum()
  {
      static int i;
      i=i+2;
      printf("%d ",i);//0+2
  }
 void multi()
  {
      static int i;
      i=i*2;
      printf("%d ",i);//0*2
  }
 void sub()
  {
      static int i;
      i=i-2;
      printf("%d ",i);//0-2
  } 