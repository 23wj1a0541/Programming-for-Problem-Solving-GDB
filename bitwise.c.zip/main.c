
#include<stdio.h>
#include<conio.h>
main()
{
    int a=4,b=6,c;
    c=a&b;
    printf("%d & %d is %d\n",a,b,c);
    c=a|b;
    printf("%d | %d is %d\n",a,b,c);
    c=a^b;
    printf("%d ^ %d is %d\n",a,b,c);
    c=~a;
    printf("~%d is %d\n",a,c);
    c=~b;
    printf("~%d is %d\n",b,c);
    c=a<<1;
    printf("%d<<1 is %d\n",a,c);
    c=b<<1;
    printf("%d<<1 is %d\n",b,c);
    c=a>>1;
    printf("%d>>1 is %d\n",a,c);
    c=b>>1;
    printf("%d>>1 is %d\n",b,c);
}
