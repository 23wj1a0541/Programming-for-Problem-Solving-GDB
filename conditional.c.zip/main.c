#include<stdio.h>
#include<conio.h>
main()
{
    int a=6,b=8,c;
    c=(a<b)?10:20;
    printf("c=%d\n",c);
    
    c=(a>b)?10:20;
    printf("c=%d\n",c);
    
    c=(a>b)?4:(a!=b)?10:20;
    printf("c=%d\n",c);
}