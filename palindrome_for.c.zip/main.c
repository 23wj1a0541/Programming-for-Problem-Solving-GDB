#include<stdio.h>
#include<conio.h>
 main()
  {
      int n1,num,rem,rev=0;
      printf("Enter the number ");
      scanf("%d",&num);
      for(n1=num;num!=0;num=num/10)
       {
           rem = num%10;
           rev = (rev*10)+rem;
       }
      printf("reverse of the number is %d\n",rev);
      if(n1==rev)
       printf("It is a palindrome");
      else
       printf("It is not a palindrome");
  }

