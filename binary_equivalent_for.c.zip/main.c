#include<stdio.h>
#include<conio.h>
 main()
  {
      int num,rem,bin,i;
      printf("Enter the number ");
      scanf("%d",&num);
      for(bin=0,i=1;num!=0;i=i*10)
       {
           rem=num%2;
           bin=bin+(rem*i);
           num=num/2;
       }
      printf("The binary equivalent value is %d",bin); 
  }

