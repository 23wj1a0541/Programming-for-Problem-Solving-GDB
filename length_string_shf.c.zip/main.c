#include<stdio.h>
#include<conio.h>
#include<string.h>
 main()
  {
      char name[20];
      int n;
      printf("Enter the string ");
      gets(name);
      n=strlen(name);
      printf("The length of the string is %d",n);
  }
