#include<stdio.h>
#include<conio.h>
 main()
  {
      int m,n,i,a[20];
      printf("Enter the number n and m number of rows ");
      scanf("%d %d",&n,&m);
      for(i=1;i<=m;i++)
       {
           a[i-1]=n*(i);
           printf("%d x %d = %d",n,i,a[i-1]);
           printf("\n");
       }
     
  }



































