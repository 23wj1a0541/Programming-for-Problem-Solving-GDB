#include<stdio.h>
#include<conio.h>
 main()
  {
      int i=1,n;
      printf("printing natural numbers from 1 to n \n");
      printf("Enter the value of n ");
      scanf("%d",&n);
      while(i<=n)
       {
           printf("%d ",i);
           i++;
       }
      
      printf("\nprinting natural numbers from n to 1 \n");
      printf("Enter the value of n ");
      scanf("%d",&n);
      i=n;
      while(i>=1)
       {
           printf("%d ",i);
           i--;
       } 
      i=0;
      printf("\n printing even numbers from 0 to n");
      printf("Enter the value of n ");
      scanf("%d",&n);
      while(i<=n)
      {
          printf("%d ",i);
          i=i+2;
      }
  }