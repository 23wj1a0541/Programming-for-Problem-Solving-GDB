#include<stdio.h>
#include<conio.h>
 main()
  {
      int fact(int);
      int n,f1;
      printf("%d",&n);
      scanf("%d",&n);
      f1=fact(n);
      printf("The factorial is %d",f1);
  }
  int fact(int n)
      {
          int i,f2=1;
          for(i=1;i<=n;i++)
           f2=f2*i;
          return(f2); 
      }