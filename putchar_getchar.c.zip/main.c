#include<stdio.h>
#include<conio.h>
 main()
  {
    char x='s',y,z;
    printf("Enter a character using getchar()\n");
    y=getchar();
    printf("Enter a character using scanf()\n");
    fflush(0);
    scanf(" %c",&z);
    printf("The entered characters are\n");
    printf("%c %c ",x,y);
    putchar(z);
  }
