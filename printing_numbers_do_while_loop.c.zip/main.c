#include<stdio.h>
#include<conio.h>
 main()
  {
      int i=1,n;
      printf("printing natural numbers from 1 to n \n");
      printf("Enter the value of n ");
      scanf("%d",&n);
      do
       {
           printf("%d ",i);
           i++;
       }while(i<=n);
      printf("\nprinting natural numbers from n to 1 \n");
      printf("Enter the value of n ");
      scanf("%d",&n);
      i=n;
      do
       {
           printf("%d ",i);
           i--;
       }while(i>=1); 
      i=0;
      printf("\n printing even numbers from 0 to n");
      printf("Enter the value of n ");
      scanf("%d",&n);
      do
      {
          printf("%d ",i);
          i=i+2;
      }while(i<=n);
  }

