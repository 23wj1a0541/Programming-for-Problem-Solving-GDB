#include<stdio.h>
 main()
  {
      void sum();//declaration of function
      sum();
  }
  void sum()
   {
       int a,b,c;
       printf("Enter a & b values ");
       scanf("%d %d",&a,&b);
       c=a+b;
       printf("sum=%d",c);
   }