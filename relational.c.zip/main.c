#include<stdio.h>
#include<conio.h>
main()
{
    int a=5,b=7,c;
    c=a<b;
    printf("comparing (%d<%d) is %d\n",a,b,c);
    c=a<=b;
    printf("comparing (%d<=%d) is %d\n",a,b,c);
    c=a>b;
    printf("comparing (%d>%d) is %d\n",a,b,c);
    c=a>=b;
    printf("comparing (%d>=%d) is %d\n",a,b,c);
    c=a==b;
    printf("comparing (%d==%d) is %d\n",a,b,c);
    c=a!=b;
    printf("comparing (%d!=%d) is %d\n",a,b,c);
}