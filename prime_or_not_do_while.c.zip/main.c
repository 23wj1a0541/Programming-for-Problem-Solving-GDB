#include<stdio.h>
#include<conio.h>
 main()
  {
      int n,flag=0,i;
      printf("Enter the n value ");
      scanf("%d",&n);
      i=2;
      do
       {
           if((n%i)==0)
            {
                flag=1;
                break;
            }
           i++;
       }while(i<n);
      if(flag==0)
       printf("prime");
      else
       printf("not a prime");
  }

