#include<stdio.h>
#include<conio.h>
 main()
  {
      int num,rem,bin=0,i=1;
      printf("Enter the number ");
      scanf("%d",&num);
      while(num!=0)
       {
           rem=num%2;
           bin=bin+(rem*i);
           num=num/2;
           i=i*10;
       }
      printf("The binary equivalent value is %d",bin); 
  }