#include<stdio.h>
#include<conio.h>
 main()
  {
      int a,b,c,n,i;
      printf("Enter n value ");
      scanf("%d",&n);
      printf("%d %d ",a,b);
      for(a=0,b=1,i=2;i<n;i++)
       {
           c=a+b;
           printf("%d ",c);
           a=b;
           b=c;
       }
  }

