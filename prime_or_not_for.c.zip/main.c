#include<stdio.h>
#include<conio.h>
 main()
  {
      int n,flag,i;
      printf("Enter the n value ");
      scanf("%d",&n);
      for(flag=0,i=2;i<n;i++)
       {
           if((n%i)==0)
            {
                flag=1;
                break;
            }
       }
      if(flag==0)
       printf("prime");
      else
       printf("not a prime");
  }

