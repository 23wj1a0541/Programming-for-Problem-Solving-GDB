#include<stdio.h>
#include<conio.h>
 main()
  {
      int a[5][5],b[5][5],c[5][5],m,n,i,j;
      printf("Enter the number of rows and coloumns of both matrices ");
      scanf("%d %d",&m,&n);
      printf("Enter the first matrix ");
      for(i=0;i<m;i++)
       {
           for(j=0;j<n;j++)
            scanf("%d",&a[i][j]);
       }
      printf("Enter the second matrix ");
      for(i=0;i<m;i++)
       {
           for(j=0;j<n;j++)
            scanf("%d",&b[i][j]);
       }
      for(i=0;i<m;i++)
       {
           for(j=0;j<n;j++)
            c[i][j] = a[i][j]+b[i][j];
       }
      printf("The addition of 2 matrices is \n");
      for(i=0;i<m;i++)
       {
           for(j=0;j<n;j++)
            printf("%d",c[i][j]);
           printf("\n");    
       }
  }
