#include<stdio.h>
#include<conio.h>
 main()
  {
      int a,b;
      printf("Enter the 2 values");
      scanf("%d %d",&a,&b);
      if(a>b)
       printf("%d is big",a);
      else
       printf("%d is big",b);
  }