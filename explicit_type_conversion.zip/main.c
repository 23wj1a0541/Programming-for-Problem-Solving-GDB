#include<stdio.h>
#include<conio.h>
 main()
  {
      int a,b;
      float c;
      printf("Enter 2 values");
      scanf("%d %d",&a,&b);
      c = (float)a/b;
      printf("%f",c);
  }
      
      