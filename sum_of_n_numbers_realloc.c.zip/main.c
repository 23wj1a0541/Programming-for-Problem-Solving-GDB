#include<stdio.h>
#include<conio.h>
#include<malloc.h>
 main()
  {
      int *ptr,n,n1,i,sum=0;
      printf("Enter the n value ");
      scanf("%d",&n);
      ptr=(int *)malloc(n * sizeof(int));
      printf("Enter the n values ");
      for(i=0;i<n;i++)
       scanf("%d",ptr+i);
      printf("The n values are "); 
      for(i=0;i<n;i++)
       printf("%d ",*(ptr+i)); 
      for(i=0;i<n;i++)
       sum=sum + *(ptr+i);
      printf("\nsum=%d",sum);
      printf("\nEnter the new incresed size of ptr ");
      scanf("%d",&n1);
      ptr=realloc(ptr,n1 * sizeof(int));
      printf("Enter the new %d values after %d \n",n1-n,*(ptr+(n-1)));
      for(i=n;i<n1;i++)
       scanf("%d",ptr+i);
      printf("The n1 values are "); 
      for(i=0;i<n1;i++)
       printf("%d ",*(ptr+i));
      sum=0; 
      for(i=0;i<n1;i++)
       sum= sum + *(ptr+i);
      printf("\nsum=%d",sum); 
  }











