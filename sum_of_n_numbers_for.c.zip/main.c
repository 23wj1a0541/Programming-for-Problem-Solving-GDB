#include<stdio.h>
#include<conio.h>
 main()
  {
      int n,i,sum;
      printf("Enter n value ");
      scanf("%d",&n);
      for(i=1,sum=0;i<=n;i++)
        sum=sum+i;
      printf("%d",sum); 
  }

