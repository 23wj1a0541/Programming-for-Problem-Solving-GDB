#include<stdio.h>
#include<conio.h>
 main()
  {
      sum();
      sum();
      sum();
  }
 void sum()
  {
      static int i;
      i=i+1;
      printf("%d ",i);
  }
  