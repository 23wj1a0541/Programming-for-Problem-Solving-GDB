#include<stdio.h>
#include<conio.h>
 main()
  {
      
      int n,i=2,j,flag;
      printf("Enter the positive integer n ");
      scanf("%d",&n);
      if(n<=1)
       printf("\nThe entered number n is not a prime\n");
      printf("The prime numbers between 1 and n are ");
      while(i<n)
       {
         flag=0;
         j=2;
           while(j<i)
            { 
                if((i%j)==0)
                 {
                    flag=1;
                    break;
                 }
              j++;   
            }
         if(flag==0)
          printf("%d ",i);
         i++; 
           
       }  
         
  }