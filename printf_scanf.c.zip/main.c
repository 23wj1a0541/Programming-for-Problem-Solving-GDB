#include<stdio.h>
#include<conio.h>
main()
{
    char a;
    int b;
    float c;
    printf("Enter a character,integer,float values\n");
    scanf("%c %d %f",&a,&b,&c);
    printf("The entered chracter,integer,float values are %c,%d,%f respecively\n",a,b,c);
}
