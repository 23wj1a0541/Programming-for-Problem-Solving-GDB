#include<stdio.h>
#include<conio.h>
 main()
  {
      int i,x,y,z,p[3];
      printf("Enter x y z values ");
      for(i=0;i<3;i++)
       scanf("%d",&p[i]);
      printf("The values of x y z are "); 
      for(i=0;i<3;i++)
       printf("%d ",p[i]); 
      printf("\nThe address of x y z are ");
      for(i=0;i<3;i++)
       printf("%u ",&p[i]);
      
  }
