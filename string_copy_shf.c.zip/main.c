#include<stdio.h>
#include<conio.h>
#include<string.h>
 main()
  {
      char name[20],name1[20];
      printf("Enter the string name = ");
      gets(name);
      strcpy(name1,name);
      printf("Enter the copied string name1 = ");
      puts(name1);
  }

