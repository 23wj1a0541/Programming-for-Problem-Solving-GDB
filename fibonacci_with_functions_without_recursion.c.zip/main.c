#include<stdio.h>
#include<conio.h>
 main()
  {
      int n;
      void fib(int);
      printf("Enter the n value ");
      scanf("%d",&n);
      fib(n);
  }
 void fib(int n)
  {
      int a=0,b=1,c,i;
      printf("%d %d ",a,b);
      for(i=2;i<n;i++)
       {
           c=a+b;
           printf("%d ",c);
           a=b;
           b=c;
       }
  }