#include<stdio.h>
#include<conio.h>
main()
{
    int a,e;
    char b,f;
    float c,g;
    double d,h;
    
    e=sizeof(a);
    f=sizeof(b);
    g=sizeof(c);
    h=sizeof(d);
    
    printf("e=%d\n",e);
    printf("f=%d\n",f);
    printf("g=%f\n",g);
    printf("h=%lf\n",h);
    
}

