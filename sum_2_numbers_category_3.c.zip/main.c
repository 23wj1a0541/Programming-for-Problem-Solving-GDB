#include<stdio.h>
#include<conio.h>
 main()
  {
      int a;
      float b,c;
      float sum(int,float);
      printf("Enter 2 values ");
      scanf("%d %f",&a,&b);
      c=sum(a,b);
      printf("sum=%f",c);
  }
  float sum (int d,float e)
        {
            float z;
            z=d+e;
            return(z);
        }