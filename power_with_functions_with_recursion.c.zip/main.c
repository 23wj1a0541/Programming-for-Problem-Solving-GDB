#include<stdio.h>
#include<conio.h>
 main()
  {
      int b,p,pw;
      int rpower(int,int);
      printf("Enter the 2 values ");
      scanf("%d %d",&b,&p);
      pw=rpower(b,p);
      printf("The power is %d",pw);
  }
 int rpower(int b,int p)
  {
      if(p==0)
       return(1);
      else
       return(b*rpower(b,(p-1)));
  }