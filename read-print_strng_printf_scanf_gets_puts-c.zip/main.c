#include<stdio.h>
#include<conio.h>
 main()
  {
      char st1[20],st2[20];
      printf("Enter the first string using scanf ");
      scanf("%s",st1);
      printf("The entered first string is %s",st1);
      printf("\nEnter the second string using gets ");
      while(getchar()!='\n');
      gets(st2);
      printf("The entered second string is ");
      puts(st2);
  }
