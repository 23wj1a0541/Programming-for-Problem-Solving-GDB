#include<stdio.h>
#include<conio.h>
 struct student
  {
      char name[20];
      int rollno;
      float height;
      int m[4];
  }std[3];
 main()
  {
      int i,j;
      printf("Enter the details of 3 students\n");
      for(i=0;i<3;i++)
       {
        scanf("%s %d %f",std[i].name,&std[i].rollno,&std[i].height);
        for(j=0;j<4;j++)
         scanf("%d",&std[i].m[j]);
       }  
      printf("\nThe details of 3 students are ");
      for(i=0;i<3;i++)
       {
        printf("%s %d %f ",std[i].name,std[i].rollno,std[i].height);
        for(j=0;j<4;j++)
         printf("%d ",std[i].m[j]);
       }
  }


