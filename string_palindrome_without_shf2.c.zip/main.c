#include<stdio.h>
#include<conio.h>
 main()
  {
      int n=0,i=0,j,k=0;
      char name1[20],name2[20];
      printf("Enter the first string ");
      gets(name1);
      while(name1[i]!='\0')
       i++;
      for(j=i-1;j>=0;j--)
       {
           name2[k]=name1[j];
           k++;
       }
      name2[k]='\0';
      for(i=0,k=0;name1[i]!='\0'&&name2[k]!='\0';i++,k++)
       {
        if(name1[i]!=name2[k])
         n=1;
       }  
      if(n==0)
       printf("It is a palindrome");
      else
       printf("It is not a palindrome");
  }


