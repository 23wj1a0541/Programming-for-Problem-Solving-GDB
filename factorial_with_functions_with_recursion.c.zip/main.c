#include<stdio.h>
#include<conio.h>
 main()
  {
      int n,f;
      int rfact(int);
      printf("Enter the n value ");
      scanf("%d",&n);
      f=rfact(n);
      printf("The factorial is %d",f);
  }
 int rfact(n)
  {
      if(n==1)
       return(1);
      else
       return(n*rfact(n-1));
  }