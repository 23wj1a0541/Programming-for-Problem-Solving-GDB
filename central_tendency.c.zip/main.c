#include<stdio.h>
#include<conio.h>
#include<math.h>
 main()
  {
      int i,num;
      float x[99],mean,variance,SD,differ,xsum=0,vsum=0;
      printf("Enter a number ");
      scanf("%d",&num);
      printf("Enter %d numbers ",num);
      for(i=0;i<num;i++)
       scanf("%f",&x[i]);
      for(i=0;i<num;i++)
       xsum=xsum+x[i];
      mean=xsum/num;
      for(i=0;i<num;i++)
       {
           differ=x[i]-mean;
           vsum=vsum+pow(differ,2);
       }
      variance=vsum/num;
      SD=sqrt(variance);
      printf("mean=%f",mean);
      printf("\nvariance=%f",variance);
      printf("\nstandard_deviation=%f",SD);
       
  }

































