#include<stdio.h>
#include<conio.h>
#include<malloc.h>
 main()
  {
      int *ptr1,*ptr2,n1,n2,i;
      printf("Enter the n1 value ");
      scanf("%d",&n1);
      printf("Enter the n2 value ");
      scanf("%d",&n2);
      ptr1=(int *)malloc(n1 * sizeof(int));
      ptr2=(int *)calloc(n2 , sizeof(int));
      printf("Enter the values of ptr1 ");
      for(i=0;i<n1;i++)
       scanf("%d",ptr1+i);
      printf("Enter the values of ptr2 "); 
      for(i=0;i<n2;i++)
       scanf("%d",ptr2+i);
      printf("The values of ptr1,ptr2 are \n"); 
      for(i=0;i<n1;i++)
       printf("%d ",*(ptr1+i));
      printf("\n"); 
      for(i=0;i<n2;i++)
       printf("%d ",*(ptr2+i));
      printf("\n"); 
      free(ptr1);
      free(ptr2);
      printf("The values of ptr1,ptr2 after deallocation are \n");
      for(i=0;i<n1;i++)
       printf("%d ",*(ptr1+i));
      printf("\n"); 
      for(i=0;i<n2;i++)
       printf("%d ",*(ptr2+i));
      printf("\n"); 
  }

















