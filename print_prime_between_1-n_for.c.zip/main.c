#include<stdio.h>
#include<conio.h>
 main()
  {
      
      int n,i,j,flag;
      printf("Enter the positive integer n ");
      scanf("%d",&n);
      if(n<=1)
       printf("\nThe entered number n is not a prime\n");
      printf("The prime numbers between 1 and n are ");
      for(i=2;i<n;i++)
       {
         for(flag=0,j=2;j<i;j++)
            { 
                if((i%j)==0)
                 {
                    flag=1;
                    break;
                 }
            }
         if(flag==0)
          printf("%d ",i);
       }  
         
  }

