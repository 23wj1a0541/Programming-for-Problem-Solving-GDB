#include<stdio.h>
#include<conio.h>
#include<string.h>
 main()
  {
   char name1[20];
   printf("Enter the first string ");
   gets(name1);
   strrev(name1);
   printf("The reversed string is ");
   puts(name1);
  } 
