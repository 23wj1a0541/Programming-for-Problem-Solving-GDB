#include<stdio.h>
#include<conio.h>
 main()
  {
      int a[20],n,*p,i,sum=0;
      p=&a[0];
      printf("Enter the n value ");
      scanf("%d",&n);
      printf("Enter the array values ");
      for(i=0;i<n;i++)
       scanf("%d",&a[i]);
      for(i=0;i<n;i++)
       sum=sum+(*(p+i));
      printf("sum=%d",sum); 
  }