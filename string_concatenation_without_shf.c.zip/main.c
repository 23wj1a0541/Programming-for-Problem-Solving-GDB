#include<stdio.h>
#include<conio.h>
 main()
  {
      char concat[40],name1[20],name2[20];
      int i,j;
      printf("Enter the first string ");
      gets(name1);
      printf("Enter the second string ");
      gets(name2);
      for(i=0;name1[i]!='\0';i++)
       concat[i]=name1[i];
      for(j=0;name2[j]!='\0';j++)
       concat[i+j]=name2[j];
       concat[i+j]='\0';
      printf("The combined string is ");
      puts(concat);
      printf("The second string is ");
      puts(name2);
  }
