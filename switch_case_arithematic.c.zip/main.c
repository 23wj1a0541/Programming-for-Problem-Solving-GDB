#include<stdio.h>
#include<conio.h>
main()
 {
     int a,b,c;
     char ch;
     printf("Enter 2 values ");
     scanf("%d %d",&a,&b);
     printf("Enter your choice ");
     getchar();
     scanf("%c",&ch);
     switch(ch)
      {
        case '+': c=a+b;
                printf("sum=%d",c);
                break;
        case '-': c=a-b;
                  printf("difference=%d",c);
                  break;    
        case '*': c=a*b;
                  printf("multiply=%d",c);
                  break;          
        case '/': c=a/b;
                  printf("quotient=%d",c);
                  break;
        case '%': c=a%b;
                  printf("remainder=%d",c);
                  break;
        default : printf("wrong choice");          
      }
 
 }
