#include<stdio.h>
#include<conio.h>
 main()
  {
      int n1,num,rem,rev=0;
      printf("Enter the number ");
      scanf("%d",&num);
      n1=num;
      while(num!=0)
       {
           rem = num%10;
           rev = (rev*10)+rem;
           num=num/10;
       }
      printf("reverse of the number is %d\n",rev);
      if(n1==rev)
       printf("It is a palindrome");
      else
       printf("It is not a palindrome");
  }