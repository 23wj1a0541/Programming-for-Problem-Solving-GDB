#include<stdio.h>
#include<conio.h>
 main()
  {
      int fact(int);
      int n,f;
      printf("Enter the n value ");
      scanf("%d",&n);
      f=fact(n);
      printf("The factorial is %d",f);
  }
 int fact(int n)
  {
      int i,f1=1;
      for(i=1;i<=n;i++)
       f1=f1*i;
      return(f1); 
  }