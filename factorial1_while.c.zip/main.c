#include<stdio.h>
#include<conio.h>
 main()
  {
      int n,i=1,fact=1;
      printf("Enter n value ");
      scanf("%d",&n);
      printf("%d!=",n);
      while(i<=n)
       {
           fact=fact*i;
           if(i!=n)
            printf("%d*",i);
           else
            printf("%d",i);
           i++;
       }
      printf("\nThe factorial of %d is %d",n,fact); 
  } 
