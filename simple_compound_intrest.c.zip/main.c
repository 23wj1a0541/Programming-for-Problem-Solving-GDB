#include<stdio.h>
#include<conio.h>
#include<math.h>
main()
{
    int p,t;
    float r,si,ci;
    printf("Enter the principal amount,time,rate of intrest\n");
    scanf("%d %d %f",&p,&t,&r);
    si=p*t*r/100;
    ci=p*(pow((1+r/100),t))-p;
    printf("The simple intrest and compound intrest are %f and %f respetively\n",si,ci);
}
