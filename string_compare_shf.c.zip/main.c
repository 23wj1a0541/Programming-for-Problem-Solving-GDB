#include<stdio.h>
#include<conio.h>
#include<string.h>
 main()
  {
      int n;
      char name1[20],name2[20];
      printf("Enter the first string ");
      gets(name1);
      printf("Enter the second string ");
      gets(name2);
      n=strcmp(name1,name2);
      if(n==0)
       printf("The 2 strings are equal");
      else
       printf("The 2 strings are not equal");
  }