#include<stdio.h>
#include<conio.h>
 struct Book
  {
      char title[20];
      int pages;
      float price;
  }B1={"PPS",20,130.50};
 main()
  {
      struct Book B2;
      printf("Enter the details of Book B2 ");
      scanf("%s %d %f",B2.title,&B2.pages,&B2.price);
      printf("The details of Book B1 are ");
      printf("%s %d %f",B1.title,B1.pages,B1.price);
      printf("\nThe details of Book B2 are ");
      printf("%s %d %f",B2.title,B2.pages,B2.price);
  }