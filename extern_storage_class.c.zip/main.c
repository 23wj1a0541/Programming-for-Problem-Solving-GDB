#include<stdio.h>
#include<conio.h>
 int i;
  main()
   {
       sum();
       sum();
       sub();
       sub();
   }
  sum()
   {
       i=i+1;
       printf("%d ",i);
   }
  sub()
   {
       i=i-1;
       printf("%d ",i);
   }