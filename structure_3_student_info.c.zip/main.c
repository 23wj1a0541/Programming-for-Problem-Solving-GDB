#include<stdio.h>
#include<conio.h>
 struct student
  {
      char name[20];
      int rollno;
      float height;
      int m1;
      int m2;
      int m3;
  };
 main()
  {
      struct student std[3];
      int i;
      printf("Enter the details of 3 students ");
      for(i=0;i<3;i++)
       scanf("%s %d %f %d %d %d",std[i].name,&std[i].rollno,&std[i].height,&std[i].m1,&std[i].m2,&std[i].m3);
      printf("The details of 3 students are ");
      for(i=0;i<3;i++)
       printf("%s %d %f %d %d %d\n",std[i].name,std[i].rollno,std[i].height,std[i].m1,std[i].m2,std[i].m3);
  }
